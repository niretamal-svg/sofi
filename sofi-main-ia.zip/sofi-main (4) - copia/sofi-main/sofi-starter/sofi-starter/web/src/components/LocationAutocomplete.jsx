import { useState, useEffect, useRef } from 'react';

export default function LocationAutocomplete({ value, onChange, placeholder, className }) {
  const [query, setQuery] = useState(value || '');
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  
  const wrapperRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    setQuery(value || '');
  }, [value]);

  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchLocations = async (searchTerm) => {
    if (!searchTerm || searchTerm.length < 3) {
      setSuggestions([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const res = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(searchTerm)}&format=json&addressdetails=1&limit=5`);
      const data = await res.json();
      
      const formatted = data.map(item => {
        const city = item.address.city || item.address.town || item.address.village || item.address.state || item.name;
        const country = item.address.country;
        if (!city || !country) return item.display_name.split(',').slice(0, 2).join(',');
        return `${city}, ${country}`;
      }).filter((v, i, a) => a.indexOf(v) === i); // Unique

      if (searchTerm.toLowerCase().includes('remot')) {
        formatted.push('Remoto');
      }

      setSuggestions(formatted.length > 0 ? formatted : ["No se encontraron resultados", "Remoto"]);
    } catch (err) {
      console.error(err);
      setSuggestions(["Remoto"]); 
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    onChange(val); 
    setShowDropdown(true);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    
    debounceRef.current = setTimeout(() => {
      searchLocations(val);
    }, 500);
  };

  const handleSelect = (suggestion) => {
    if (suggestion === "No se encontraron resultados") return;
    setQuery(suggestion);
    onChange(suggestion);
    setShowDropdown(false);
  };

  return (
    <div className="pp-autocomplete-container" ref={wrapperRef}>
      <input
        type="text"
        className={className}
        placeholder={placeholder}
        value={query}
        onChange={handleInputChange}
        onFocus={() => { if (query.length >= 3) setShowDropdown(true); }}
      />
      
      {showDropdown && (query.length >= 3) && (
        <ul className="pp-autocomplete-dropdown">
          {loading ? (
            <li className="pp-autocomplete-item pp-loading">Buscando...</li>
          ) : suggestions.length > 0 ? (
            suggestions.map((suggestion, idx) => (
              <li 
                key={idx} 
                className={`pp-autocomplete-item ${suggestion === "No se encontraron resultados" ? "disabled" : ""}`}
                onClick={() => handleSelect(suggestion)}
              >
                {suggestion}
              </li>
            ))
          ) : null}
        </ul>
      )}
    </div>
  );
}
