import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { useMemo, useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext.jsx';
import { api } from '../services/api.js';
import LocationAutocomplete from '../components/LocationAutocomplete.jsx';

export default function PublicacionPerfilPage() {
    const navigate = useNavigate();
    const { logout, user } = useAuth();
    const { id } = useParams();
    const location = useLocation();

    const vacanteNueva = location.state?.vacante || null;
    const codigoNueva = location.state?.codigo || '#000';

    const isNueva = id === 'nueva';

    const [isGenerating, setIsGenerating] = useState(false);
    const [suggestions, setSuggestions] = useState([]);
    const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
    const [showPreview, setShowPreview] = useState(false);
    const [previewTab, setPreviewTab] = useState('general');

    const [form, setForm] = useState({
        titulo: vacanteNueva?.titulo || 'Vendedor(a) de Mostrador – Pastelería SKIC',
        categoria: vacanteNueva?.categoria || 'Ventas',
        jornada: 'Tiempo completo · Turno rotativo',
        salario: vacanteNueva?.salario || '800000',
        ubicacion: vacanteNueva?.ubicacion || 'Santiago, Chile',
        descripcion:
            vacanteNueva?.descripcion ||
            'El vendedor(a) de mostrador es responsable de brindar una atención cálida, rápida y eficiente al cliente, garantizando una experiencia de compra positiva. También apoya en la exhibición de productos, orden del punto de venta y trabajo en equipo.',
        requisitos:
            '• Enseñanza media completa\n• Actitud de servicio y trabajo en equipo\n• Disponibilidad de horario\n• Experiencia en atención de clientes deseable'
    });

    const codigo = useMemo(() => {
        if (location.state?.codigo) return location.state.codigo;
        if (!id) return '----';
        return `#${String(id).slice(-4).toUpperCase()}`;
    }, [id, location.state]);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const handleChange = (field, value) => {
        setForm((prev) => ({
            ...prev,
            [field]: value
        }));
    };

    const handleGenerarConIA = async () => {
        if (!form.titulo) return alert('Debes ingresar al menos un título de anuncio.');
        setIsGenerating(true);
        setForm(prev => ({ ...prev, descripcion: '', requisitos: '' }));
        
        try {
            const token = localStorage.getItem('sofi_token');
            const response = await fetch(`${import.meta.env.VITE_API_URL}/ai/generate-profile`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
                },
                body: JSON.stringify(form)
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf-8');
            let done = false;
            let fullText = '';
            let buffer = '';
            
            while (!done) {
                const { value, done: readerDone } = await reader.read();
                done = readerDone;
                if (value) {
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split('\n\n');
                    buffer = lines.pop(); // Keep the last incomplete part in the buffer
                    
                    for (const line of lines) {
                        if (line.startsWith('data: ')) {
                            const dataStr = line.replace('data: ', '').trim();
                            if (dataStr === '[DONE]') {
                                done = true;
                                break;
                            }
                            try {
                                const parsed = JSON.parse(dataStr);
                                fullText += parsed.text;
                                
                                let desc = '';
                                let req = '';
                                
                                console.log("✅ Parsed text chunk:", parsed.text);
                                console.log("📝 Full text so far:", fullText);
                                
                                let descMatch = fullText.match(/\[DESCRIPCION\][^\n]*\n([\s\S]*?)(?=\[REQUISITOS\]|$)/i);
                                if (!descMatch) descMatch = fullText.match(/DESCRIPCI[OÓ]N[^\n]*\n([\s\S]*?)(?=REQUISITOS|$)/i);
                                if (descMatch) {
                                    desc = descMatch[1].trim();
                                    console.log("✅ Extracted desc:", desc);
                                } else {
                                    desc = fullText;
                                }
                                
                                let reqMatch = fullText.match(/\[REQUISITOS\][^\n]*\n([\s\S]*)/i);
                                if (!reqMatch) reqMatch = fullText.match(/REQUISITOS[^\n]*\n([\s\S]*)/i);
                                if (reqMatch) {
                                    req = reqMatch[1].trim();
                                }
                                
                                // We store them to state them later with typewriter
                                window.finalDesc = desc;
                                window.finalReq = req;
                            } catch (e) {
                                console.error("❌ Error parsing JSON payload or setting form:", e, "Raw data:", dataStr);
                            }
                         }
                    }
                }
            }
            
            // Typewriter effect
            let i = 0;
            let j = 0;
            const targetDesc = window.finalDesc || fullText;
            const targetReq = window.finalReq || '';
            
            const timer = setInterval(() => {
                setForm(prev => {
                    let updatedDesc = prev.descripcion;
                    let updatedReq = prev.requisitos;
                    let changed = false;
                    
                    if (i < targetDesc.length) {
                        i += 2;
                        updatedDesc = targetDesc.substring(0, i);
                        changed = true;
                    } else if (updatedDesc !== targetDesc) {
                        updatedDesc = targetDesc;
                        changed = true;
                    }
                    
                    // Optional: delay requirements typing slightly by requiring i to be > 20
                    if (i > 20 && j < targetReq.length) {
                        j += 2;
                        updatedReq = targetReq.substring(0, j);
                        changed = true;
                    } else if (i > 20 && updatedReq !== targetReq) {
                        updatedReq = targetReq;
                        changed = true;
                    }
                    
                    if (!changed) {
                        clearInterval(timer);
                        setIsGenerating(false);
                    }
                    
                    return changed ? { ...prev, descripcion: updatedDesc, requisitos: updatedReq } : prev;
                });
            }, 10);
            
        } catch (error) {
            console.error(error);
            alert('Error al generar con IA. Revisa la consola o asegúrate de configurar GEMINI_API_KEY en el backend.');
            setIsGenerating(false);
        }
    };

    const handleObtenerSugerencias = async () => {
        setIsLoadingSuggestions(true);
        try {
            const { data } = await api.post('/ai/suggestions', form);
            
            // Typewriter effect for suggestions
            setSuggestions(["", "", ""]);
            let charsTyped = 0;
            const maxLen = Math.max(...data.map(s => s.length));
            
            const timer = setInterval(() => {
                let changed = false;
                setSuggestions(prev => {
                    const nextSuggs = [...prev];
                    data.forEach((targetSugg, index) => {
                        if (charsTyped < targetSugg.length) {
                            nextSuggs[index] = targetSugg.substring(0, charsTyped + 2);
                            changed = true;
                        } else if (nextSuggs[index] !== targetSugg) {
                            nextSuggs[index] = targetSugg;
                            changed = true;
                        }
                    });
                    
                    if (!changed) {
                        clearInterval(timer);
                        setIsLoadingSuggestions(false);
                    }
                    return changed ? nextSuggs : prev;
                });
                charsTyped += 2;
            }, 10);
            
        } catch (error) {
            console.error(error);
            alert('Error al obtener sugerencias.');
            setIsLoadingSuggestions(false);
        }
    };

    const handleContinuar = async () => {
        try {
            if (id && id !== 'nueva') {
                const payload = {
                    titulo: form.titulo.trim(),
                    salario: Number(form.salario),
                    ubicacion: form.ubicacion.trim(),
                    descripcion: form.descripcion.trim()
                };
                
                await api.put(`/vacantes/${id}`, payload);
            }

            navigate('/publicacion-portales/seleccion-portales', {
                state: {
                    vacante: form,
                    codigo
                }
            });
        } catch (err) {
            console.error("Error al actualizar la vacante:", err);
            alert("Ocurrió un error al intentar guardar los cambios en la base de datos.");
        }
    };

    return (
        <div className="pp-page-shell">
            <header className="pp-topbar">
                <div className="pp-topbar-logo">SOFI · Sistema de Reclutamiento</div>

                <div className="pp-topbar-user">
                    <span>
                        {user?.nombre ? user.nombre.toUpperCase() : 'USUARIO'} ·{' '}
                        {user?.rol ? user.rol.toUpperCase() : 'ADMIN'}
                    </span>
                    <button className="pp-btn pp-btn-teal pp-btn-sm pp-btn-auto" onClick={handleLogout}>
                        SALIR
                    </button>
                </div>
            </header>

            <div className="pp-breadcrumb">
                <a href="/">Menú administrador</a>
                <span>›</span>
                <a href="/vacantes">Gestión de vacantes</a>
                <span>›</span>
                <a href="/publicacion-portales">Publicación en portales</a>
                <span>›</span>
                <strong>Perfil & descripción</strong>
            </div>

            <main className="pp-page">
                <h1 className="pp-title">Perfil y descripción del cargo</h1>
                <p className="pp-subtitle">
                    Completa la información que se mostrará en los portales de empleo.
                </p>

                <div className="pp-stepper">
                    <StepItem number="✓" label="Paso 1" title="Seleccionar vacante" done />
                    <StepItem number="2" label="Paso 2" title="Perfil & descripción" active />
                    <StepItem number="3" label="Paso 3" title="Seleccionar portales" />
                    <StepItem number="4" label="Paso 4" title="Confirmar & publicar" last />
                </div>

                <div className="pp-grid">
                    <section className="pp-card">
                        <div className="pp-card-header pp-card-header-row">
                            <div className="pp-card-title">✨ Perfil del candidato</div>
                            <div className="pp-inline-actions">
                                <button className="pp-btn pp-btn-ai pp-btn-sm pp-btn-auto" onClick={handleGenerarConIA} disabled={isGenerating}>
                                    {isGenerating ? '✦ Generando...' : '✦ Generar con IA'}
                                </button>
                                <button className="pp-btn pp-btn-ghost pp-btn-sm pp-btn-auto">
                                    Cargar perfil existente
                                </button>
                            </div>
                        </div>

                        <div className="pp-card-body">
                            <div className="pp-ai-banner">
                                <div className="pp-ai-icon">✦</div>
                                <div>
                                    <div className="pp-ai-title">Sofi IA · Asistente de perfiles</div>
                                    <div className="pp-ai-text">
                                        Puedes generar automáticamente un perfil de cargo con mejor redacción para
                                        publicación en portales.
                                    </div>
                                </div>
                            </div>

                            <div className="pp-form-group">
                                <label className="pp-label">Título del anuncio</label>
                                <input
                                    className="pp-input"
                                    value={form.titulo}
                                    onChange={(e) => handleChange('titulo', e.target.value)}
                                />
                            </div>

                            <div className="pp-form-grid">
                                <div className="pp-form-group">
                                    <label className="pp-label">Categoría</label>
                                    <input
                                        className="pp-input"
                                        value={form.categoria}
                                        onChange={(e) => handleChange('categoria', e.target.value)}
                                    />
                                </div>

                                <div className="pp-form-group">
                                    <label className="pp-label">Tipo de jornada</label>
                                    <input
                                        className="pp-input"
                                        value={form.jornada}
                                        onChange={(e) => handleChange('jornada', e.target.value)}
                                    />
                                </div>

                                <div className="pp-form-group">
                                    <label className="pp-label">Salario</label>
                                    <input
                                        className="pp-input"
                                        type="number"
                                        min="0"
                                        onKeyDown={(e) => {
                                            if (e.key === '-' || e.key === 'e') {
                                                e.preventDefault();
                                            }
                                        }}
                                        value={form.salario}
                                        onChange={(e) => handleChange('salario', e.target.value)}
                                    />
                                </div>

                                <div className="pp-form-group">
                                    <label className="pp-label">Ubicación</label>
                                    <LocationAutocomplete
                                        className="pp-input"
                                        placeholder="Ej. Santiago, Chile"
                                        value={form.ubicacion}
                                        onChange={(val) => handleChange('ubicacion', val)}
                                    />
                                </div>
                            </div>

                            <div className="pp-form-group">
                                <label className="pp-label">Descripción del puesto</label>
                                <textarea
                                    className="pp-input pp-textarea pp-textarea-lg"
                                    value={form.descripcion}
                                    onChange={(e) => handleChange('descripcion', e.target.value)}
                                />
                            </div>

                            <div className="pp-form-group">
                                <label className="pp-label">Requisitos</label>
                                <textarea
                                    className="pp-input pp-textarea"
                                    value={form.requisitos}
                                    onChange={(e) => handleChange('requisitos', e.target.value)}
                                />
                            </div>

                            <div className="pp-actions">
                                <button
                                    className="pp-btn pp-btn-ghost pp-btn-auto"
                                    onClick={() => navigate('/publicacion-portales')}
                                >
                                    ← Regresar
                                </button>

                                <button
                                    className="pp-btn pp-btn-ghost pp-btn-auto"
                                    onClick={() => setShowPreview(true)}
                                >
                                    👁 Vista Previa
                                </button>

                                <button className="pp-btn pp-btn-primary pp-btn-auto" onClick={handleContinuar}>
                                    Continuar → Seleccionar portales
                                </button>
                            </div>
                        </div>
                    </section>

                    <aside className="pp-side-stack">
                        <div className="pp-card pp-sidebar">
                            <div className="pp-card-header">
                                <div className="pp-card-title">💡 Sugerencias IA</div>
                            </div>

                            <div className="pp-card-body">
                                {suggestions.length > 0 ? (
                                    <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '13px', color: '#4b5563', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                        {suggestions.map((sug, i) => <li key={i}>{sug}</li>)}
                                    </ul>
                                ) : (
                                    <div style={{ minHeight: '100px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9ca3af', fontStyle: 'italic', background: '#f9fafb', borderRadius: '8px', border: '1px dashed #d1d5db', textAlign: 'center', padding: '12px', fontSize: '13px' }}>
                                        Haz clic en obtener sugerencias para analizar tu oferta.
                                    </div>
                                )}
                                <button 
                                    className="pp-btn pp-btn-sm" 
                                    style={{ width: '100%', marginTop: '12px', background: '#f3f4f6', color: '#374151', border: '1px solid #d1d5db' }}
                                    onClick={handleObtenerSugerencias}
                                    disabled={isLoadingSuggestions}
                                >
                                    {isLoadingSuggestions ? 'Analizando...' : 'Obtener Sugerencias'}
                                </button>
                            </div>
                        </div>

                        <div className="pp-card">
                            <div className="pp-card-header">
                                <div className="pp-card-title">📂 Resumen del perfil</div>
                            </div>

                            <div className="pp-card-body">
                                <div className="pp-sidebar-code">{codigo}</div>
                                <div className="pp-sidebar-name">{form.titulo}</div>
                                <div className="pp-sidebar-meta">
                                    {form.categoria} · {form.ubicacion}
                                </div>

                                <hr className="pp-divider" />

                                <div className="pp-field">
                                    <div className="pp-field-label">Jornada</div>
                                    <div className="pp-field-value">{form.jornada}</div>
                                </div>

                                <div className="pp-field">
                                    <div className="pp-field-label">Salario</div>
                                    <div className="pp-field-value">{form.salario}</div>
                                </div>

                                <div className="pp-field">
                                    <div className="pp-field-label">Descripción</div>
                                    <div className="pp-field-value pp-description">{form.descripcion}</div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </main>

            {showPreview && (
                <div className="pp-modal-overlay" onClick={() => setShowPreview(false)}>
                    <div className="pp-modal" onClick={e => e.stopPropagation()}>
                        <div className="pp-modal-header">
                            <h2 className="pp-modal-title">Vista Previa de la Vacante</h2>
                            <button className="pp-modal-close" onClick={() => setShowPreview(false)}>×</button>
                        </div>
                        <div className="pp-modal-body">
                            <div className="pp-preview-tabs">
                                <button className={`pp-preview-tab ${previewTab === 'general' ? 'active' : ''}`} onClick={() => setPreviewTab('general')}>General</button>
                                <button className={`pp-preview-tab ${previewTab === 'linkedin' ? 'active' : ''}`} onClick={() => setPreviewTab('linkedin')}>LinkedIn</button>
                                <button className={`pp-preview-tab ${previewTab === 'indeed' ? 'active' : ''}`} onClick={() => setPreviewTab('indeed')}>Indeed</button>
                                <button className={`pp-preview-tab ${previewTab === 'computrabajo' ? 'active' : ''}`} onClick={() => setPreviewTab('computrabajo')}>Computrabajo</button>
                            </div>

                            {previewTab === 'general' && (
                                <div className="portal-mockup">
                                    <div className="pp-preview-header">
                                        <h1 className="pp-preview-title">{form.titulo || 'Sin título'}</h1>
                                        <div className="pp-preview-meta">
                                            <span>🏢 {form.categoria || 'Sin categoría'}</span>
                                            <span>📍 {form.ubicacion || 'Sin ubicación'}</span>
                                            <span>⏱ {form.jornada || 'Sin jornada'}</span>
                                            <span>💰 ${form.salario || '0'}</span>
                                        </div>
                                    </div>
                                    <div className="pp-preview-section">
                                        <h3>Descripción del Puesto</h3>
                                        <div className="pp-preview-text">
                                            {form.descripcion || 'No hay descripción detallada.'}
                                        </div>
                                    </div>
                                    <div className="pp-preview-section">
                                        <h3>Requisitos</h3>
                                        <div className="pp-preview-text">
                                            {form.requisitos || 'No se han especificado requisitos.'}
                                        </div>
                                    </div>
                                </div>
                            )}

                            {previewTab === 'linkedin' && (
                                <div className="portal-mockup linkedin-mockup">
                                    <div className="job-title">{form.titulo || 'Sin título'}</div>
                                    <div className="company-name">Sofi Tech <span>•</span> {form.ubicacion || 'Ubicación'} <span>•</span> Hace 2 horas</div>
                                    <div className="job-meta">
                                        <span className="meta-tag">💼 {form.jornada || 'Jornada'}</span>
                                        <span className="meta-tag">💰 ${form.salario || 'Salario'}</span>
                                        <span className="meta-tag">🏢 {form.categoria || 'Categoría'}</span>
                                    </div>
                                    <button className="apply-btn">Solicitar</button>
                                    <div className="job-description">
                                        <h3>Acerca del empleo</h3>
                                        <div>{form.descripcion || 'Sin descripción.'}</div>
                                        <h3>Requisitos</h3>
                                        <div>{form.requisitos || 'Sin requisitos.'}</div>
                                    </div>
                                </div>
                            )}

                            {previewTab === 'indeed' && (
                                <div className="portal-mockup indeed-mockup">
                                    <div className="job-title">{form.titulo || 'Sin título'}</div>
                                    <div className="company-name">Sofi Tech</div>
                                    <div className="job-meta">
                                        <span className="meta-tag">📍 {form.ubicacion || 'Ubicación'}</span>
                                        <span className="meta-tag">💰 ${form.salario || 'Salario'} a month</span>
                                        <span className="meta-tag">💼 {form.jornada || 'Jornada'}</span>
                                    </div>
                                    <button className="apply-btn">Apply now</button>
                                    <div className="job-description">
                                        <h3>Job details</h3>
                                        <div>{form.descripcion || 'Sin descripción.'}</div>
                                        <h3>Qualifications</h3>
                                        <div>{form.requisitos || 'Sin requisitos.'}</div>
                                    </div>
                                </div>
                            )}

                            {previewTab === 'computrabajo' && (
                                <div className="portal-mockup computrabajo-mockup">
                                    <div className="job-title">{form.titulo || 'Sin título'}</div>
                                    <div className="company-name">Sofi Tech <span>•</span> {form.ubicacion || 'Ubicación'}</div>
                                    <div className="job-meta">
                                        <span className="meta-tag">Salario: ${form.salario || '0'}</span>
                                        <span className="meta-tag">Tipo de contrato: {form.jornada || 'Jornada'}</span>
                                    </div>
                                    <button className="apply-btn">Postularme</button>
                                    <div className="job-description">
                                        <h3>Descripción de la vacante</h3>
                                        <div>{form.descripcion || 'Sin descripción.'}</div>
                                        <h3>Requerimientos</h3>
                                        <div>{form.requisitos || 'Sin requisitos.'}</div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

function StepItem({ number, label, title, active = false, done = false, last = false }) {
    return (
        <div className={`pp-step ${active ? 'active' : ''} ${done ? 'done' : ''} ${last ? 'last' : ''}`}>
            <div className="pp-step-num">{number}</div>
            <div className="pp-step-info">
                <div className="pp-step-label">{label}</div>
                <div className="pp-step-title">{title}</div>
            </div>
        </div>
    );
}