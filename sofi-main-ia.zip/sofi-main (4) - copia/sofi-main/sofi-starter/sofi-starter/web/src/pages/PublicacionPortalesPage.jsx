import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api.js';
import LocationAutocomplete from '../components/LocationAutocomplete.jsx';
import { useAuth } from '../contexts/AuthContext.jsx';

export default function PublicacionPortalesPage() {
  const navigate = useNavigate();
  const { logout, user } = useAuth();

  const [vacantes, setVacantes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedVacante, setSelectedVacante] = useState(null);

  const [activeTab, setActiveTab] = useState('existentes');
  const [showFormError, setShowFormError] = useState(false);

  const [nuevaVacante, setNuevaVacante] = useState({
    titulo: '',
    empresa: '',
    estado: 'Activa',
    ubicacion: '',
    modalidad: 'Presencial',
    salario: '',
    descripcion: ''
  });

  const fetchVacantes = async () => {
    try {
      setLoading(true);
      setError('');

      const { data } = await api.get('/vacantes');
      const lista = data.data || [];

      setVacantes(lista);

      if (lista.length > 0) {
        setSelectedVacante(lista[0]);
      }
    } catch (err) {
      setError('No se pudieron cargar las vacantes.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVacantes();
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleContinuar = async () => {
    if (activeTab === 'nueva') {
      if (!isNuevaVacanteValida) {
        setShowFormError(true);
        return;
      }

      try {
        const payload = {
          titulo: nuevaVacante.titulo.trim(),
          empresa: nuevaVacante.empresa.trim(),
          ubicacion: nuevaVacante.ubicacion.trim(),
          modalidad: nuevaVacante.modalidad,
          descripcion: nuevaVacante.descripcion.trim(),
          salario: Number(nuevaVacante.salario),
          estado: nuevaVacante.estado || 'Activa'
        };

        const { data } = await api.post('/vacantes', payload);
        const creada = data.data;

        setVacantes((prev) => [creada, ...prev]);

        navigate(`/publicacion-portales/${creada._id}/perfil`, {
          state: { vacante: creada, codigo: `#${creada.numero || String(creada._id).slice(-4).toUpperCase()}` }
        });
        return;
      } catch (err) {
        setError('No se pudo crear la vacante para continuar.');
        return;
      }
    }

    if (!selectedVacante) return;
    navigate(`/publicacion-portales/${selectedVacante._id}/perfil`, {
      state: { vacante: selectedVacante, codigo: `#${selectedVacante.numero || String(selectedVacante._id).slice(-4).toUpperCase()}` }
    });
  };

  const codigoVacante = useMemo(() => {
    if (!selectedVacante?._id) return '----';
    return selectedVacante.numero || String(selectedVacante._id).slice(-4).toUpperCase();
  }, [selectedVacante]);

  const isNuevaVacanteValida =
    nuevaVacante.titulo.trim() &&
    nuevaVacante.empresa.trim() &&
    nuevaVacante.ubicacion.trim() &&
    String(nuevaVacante.salario).trim() &&
    nuevaVacante.descripcion.trim();

  const handleNuevaVacanteChange = (field, value) => {
    setNuevaVacante((prev) => ({
      ...prev,
      [field]: value
    }));
    setShowFormError(false);
  };

  const guardarComoBorrador = async () => {
    if (!isNuevaVacanteValida) {
      setShowFormError(true);
      return;
    }

    try {
      const payload = {
        titulo: nuevaVacante.titulo.trim(),
        empresa: nuevaVacante.empresa.trim(),
        ubicacion: nuevaVacante.ubicacion.trim(),
        modalidad: nuevaVacante.modalidad,
        descripcion: nuevaVacante.descripcion.trim(),
        salario: Number(nuevaVacante.salario),
        estado: 'Pausada'
      };

      const { data } = await api.post('/vacantes', payload);
      const creada = data.data;

      setVacantes((prev) => [creada, ...prev]);
      setSelectedVacante(creada);
      setActiveTab('existentes');
      setShowFormError(false);

      setNuevaVacante({
        titulo: '',
        empresa: '',
        estado: 'Activa',
        ubicacion: '',
        modalidad: 'Presencial',
        salario: '',
        descripcion: ''
      });
    } catch (err) {
      setError('No se pudo guardar la vacante en el servidor.');
    }
  };

  return (
    <div className="pp-page-shell">
      <header className="pp-topbar">
        <div className="pp-topbar-logo">SOFI · Sistema de Reclutamiento</div>

        <div className="pp-topbar-user">
          <span>
            {user?.nombre ? user.nombre.toUpperCase() : 'USUARIO'} ·{' '}
            {user?.rol ? user.rol.toUpperCase() : 'ADMIN'}
          </span>
          <button className="pp-btn pp-btn-teal pp-btn-sm pp-btn-auto" onClick={handleLogout}>
            SALIR
          </button>
        </div>
      </header>

      <div className="pp-breadcrumb">
        <a href="/">Menú administrador</a>
        <span>›</span>
        <a href="/vacantes">Gestión de vacantes</a>
        <span>›</span>
        <strong>Publicación en portales</strong>
      </div>

      <main className="pp-page">
        <h1 className="pp-title">Publicación en portales de empleo</h1>
        <p className="pp-subtitle">
          Define el flujo inicial de publicación seleccionando una vacante existente o creando una nueva.
        </p>

        <div className="pp-stepper">
          <StepItem number="1" label="Paso 1" title="Seleccionar vacante" active />
          <StepItem number="2" label="Paso 2" title="Perfil & descripción" />
          <StepItem number="3" label="Paso 3" title="Seleccionar portales" />
          <StepItem number="4" label="Paso 4" title="Confirmar & publicar" last />
        </div>

        {error && <div className="pp-alert pp-alert-error">{error}</div>}

        <div className="pp-grid">
          <section className="pp-card">
            <div className="pp-card-header">
              <div className="pp-card-title">
                {activeTab === 'existentes'
                  ? '📋 Selecciona la vacante a publicar'
                  : '➕ Crear nueva vacante'}
              </div>
            </div>

            <div className="pp-card-body">
              <div className="pp-tabs">
                <button
                  className={`pp-tab ${activeTab === 'existentes' ? 'active' : ''}`}
                  onClick={() => setActiveTab('existentes')}
                >
                  Vacantes existentes
                </button>
                <button
                  className={`pp-tab ${activeTab === 'nueva' ? 'active' : ''}`}
                  onClick={() => setActiveTab('nueva')}
                >
                  + Crear nueva vacante
                </button>
              </div>

              {activeTab === 'existentes' ? (
                <>
                  {loading ? (
                    <p className="pp-empty">Cargando vacantes...</p>
                  ) : vacantes.length === 0 ? (
                    <p className="pp-empty">No hay vacantes registradas todavía.</p>
                  ) : (
                    <div className="pp-table-wrap">
                      <table className="pp-table">
                        <thead>
                          <tr>
                            <th></th>
                            <th>Código</th>
                            <th>Nombre</th>
                            <th>Empresa</th>
                            <th>Modalidad</th>
                            <th>Estado</th>
                          </tr>
                        </thead>
                        <tbody>
                          {vacantes.map((vacante) => {
                            const isSelected = selectedVacante?._id === vacante._id;

                            return (
                              <tr
                                key={vacante._id}
                                className={isSelected ? 'selected' : ''}
                                onClick={() => setSelectedVacante(vacante)}
                              >
                                <td>
                                  <input
                                    type="radio"
                                    name="vacante"
                                    checked={isSelected}
                                    onChange={() => setSelectedVacante(vacante)}
                                  />
                                </td>

                                <td>
                                  <span className="pp-code">
                                    #{vacante.numero || String(vacante._id || '').slice(-4).toUpperCase()}
                                  </span>
                                </td>

                                <td>
                                  <div className="pp-cell-title">{vacante.titulo}</div>
                                  <div className="pp-cell-sub">
                                    {vacante.empresa} · {vacante.ubicacion}
                                  </div>
                                </td>

                                <td>{vacante.empresa}</td>
                                <td>{vacante.modalidad}</td>
                                <td>
                                  <EstadoTag estado={vacante.estado} />
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}

                  <div className="pp-note">
                    En este paso usamos las vacantes existentes de tu API.
                  </div>
                </>
              ) : (
                <>
                  <div className="pp-code-box">
                    <div>
                      <div className="pp-field-label">Código de la vacante</div>
                      <div className="pp-code-big" style={{ fontSize: '14px', color: '#6b7280', fontWeight: 'normal', marginTop: '8px' }}>
                        El código se generará automáticamente al guardar la vacante.
                      </div>
                    </div>
                  </div>

                  <div className="pp-form-grid">
                    <div className="pp-form-group pp-full">
                      <label className="pp-label">Nombre de la vacante *</label>
                      <input
                        className="pp-input"
                        value={nuevaVacante.titulo}
                        onChange={(e) => handleNuevaVacanteChange('titulo', e.target.value)}
                        placeholder="Ej. Gerente de Ventas Regional"
                      />
                    </div>

                    <div className="pp-form-group">
                      <label className="pp-label">Empresa *</label>
                      <input
                        className="pp-input"
                        value={nuevaVacante.empresa}
                        onChange={(e) => handleNuevaVacanteChange('empresa', e.target.value)}
                        placeholder="Ej. SKIC"
                      />
                    </div>



                    <div className="pp-form-group">
                      <label className="pp-label">Estado</label>
                      <select
                        className="pp-input"
                        value={nuevaVacante.estado}
                        onChange={(e) => handleNuevaVacanteChange('estado', e.target.value)}
                      >
                        <option>Activa</option>
                        <option>Pausada</option>
                        <option>Cerrada</option>
                      </select>
                    </div>

                    <div className="pp-form-group">
                      <label className="pp-label">Modalidad</label>
                      <select
                        className="pp-input"
                        value={nuevaVacante.modalidad}
                        onChange={(e) => handleNuevaVacanteChange('modalidad', e.target.value)}
                      >
                        <option>Presencial</option>
                        <option>Hibrido</option>
                        <option>Remoto</option>
                      </select>
                    </div>

                    <div className="pp-form-group">
                      <label className="pp-label">Ubicación</label>
                      <LocationAutocomplete
                        className="pp-input"
                        placeholder="Ej. Santiago, Chile"
                        value={nuevaVacante.ubicacion}
                        onChange={(val) => handleNuevaVacanteChange('ubicacion', val)}
                      />
                    </div>

                    <div className="pp-form-group">
                      <label className="pp-label">Salario</label>
                      <input
                        className="pp-input"
                        type="number"
                        min="0"
                        onKeyDown={(e) => {
                          if (e.key === '-' || e.key === 'e') {
                            e.preventDefault();
                          }
                        }}
                        value={nuevaVacante.salario}
                        onChange={(e) => handleNuevaVacanteChange('salario', e.target.value)}
                        placeholder="Ej. 800000"
                      />
                    </div>

                    <div className="pp-form-group pp-full">
                      <label className="pp-label">Descripción</label>
                      <textarea
                        className="pp-input pp-textarea"
                        value={nuevaVacante.descripcion}
                        onChange={(e) => handleNuevaVacanteChange('descripcion', e.target.value)}
                        placeholder="Describe brevemente la vacante..."
                      />
                    </div>
                  </div>

                  {showFormError && (
                    <div className="pp-alert pp-alert-warning">
                      Completa al menos: nombre, empresa, ubicación, salario y descripción.
                    </div>
                  )}

                  <div className="pp-actions">
                    <button className="pp-btn pp-btn-ghost pp-btn-auto" onClick={guardarComoBorrador}>
                      💾 Guardar como borrador
                    </button>
                    <button className="pp-btn pp-btn-primary pp-btn-auto" onClick={handleContinuar}>
                      Guardar y continuar →
                    </button>
                  </div>
                </>
              )}
            </div>
          </section>

          <aside className="pp-card pp-sidebar">
            <div className="pp-card-header">
              <div className="pp-card-title">
                {activeTab === 'existentes' ? '📌 Vacante seleccionada' : '📌 Nueva vacante'}
              </div>
            </div>

            <div className="pp-card-body">
              {activeTab === 'existentes' ? (
                !selectedVacante ? (
                  <p className="pp-empty">Selecciona una vacante para ver su detalle.</p>
                ) : (
                  <>
                    <div className="pp-sidebar-code">#{codigoVacante}</div>
                    <div className="pp-sidebar-name">{selectedVacante.titulo}</div>
                    <div className="pp-sidebar-meta">
                      {selectedVacante.empresa} · {selectedVacante.modalidad} ·{' '}
                      {selectedVacante.estado}
                    </div>

                    <hr className="pp-divider" />

                    <div className="pp-field">
                      <div className="pp-field-label">Empresa</div>
                      <div className="pp-field-value">{selectedVacante.empresa}</div>
                    </div>

                    <div className="pp-field">
                      <div className="pp-field-label">Ubicación</div>
                      <div className="pp-field-value">{selectedVacante.ubicacion}</div>
                    </div>

                    <div className="pp-field">
                      <div className="pp-field-label">Salario</div>
                      <div className="pp-field-value">
                        ${Number(selectedVacante.salario || 0).toLocaleString('es-CL')}
                      </div>
                    </div>

                    <div className="pp-field">
                      <div className="pp-field-label">Descripción</div>
                      <div className="pp-field-value pp-description">
                        {selectedVacante.descripcion || 'Sin descripción'}
                      </div>
                    </div>

                    <button className="pp-btn pp-btn-primary" onClick={handleContinuar}>
                      Continuar →
                    </button>
                  </>
                )
              ) : (
                <>
                  <div className="pp-sidebar-code" style={{ color: '#9ca3af' }}>#---</div>
                  <div className="pp-sidebar-name">
                    {nuevaVacante.titulo || 'Nombre de la vacante...'}
                  </div>
                  <div className="pp-sidebar-meta">
                    {nuevaVacante.empresa || 'Empresa'} · {nuevaVacante.modalidad} ·{' '}
                    {nuevaVacante.estado}
                  </div>

                  <hr className="pp-divider" />

                  <div className="pp-field">
                    <div className="pp-field-label">Empresa</div>
                    <div className="pp-field-value">
                      {nuevaVacante.empresa || 'Sin definir'}
                    </div>
                  </div>

                  <div className="pp-field">
                    <div className="pp-field-label">Estado</div>
                    <div className="pp-field-value">
                      {nuevaVacante.estado || 'Sin definir'}
                    </div>
                  </div>

                  <div className="pp-field">
                    <div className="pp-field-label">Ubicación</div>
                    <div className="pp-field-value">
                      {nuevaVacante.ubicacion || 'Sin definir'}
                    </div>
                  </div>

                  <div className="pp-field">
                    <div className="pp-field-label">Salario</div>
                    <div className="pp-field-value">
                      {nuevaVacante.salario
                        ? `$${Number(nuevaVacante.salario).toLocaleString('es-CL')}`
                        : 'Sin definir'}
                    </div>
                  </div>

                  <div className="pp-field">
                    <div className="pp-field-label">Descripción</div>
                    <div className="pp-field-value pp-description">
                      {nuevaVacante.descripcion || 'Sin descripción'}
                    </div>
                  </div>

                  <button className="pp-btn pp-btn-primary" onClick={handleContinuar}>
                    Guardar y continuar →
                  </button>
                </>
              )}
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}

function StepItem({ number, label, title, active = false, last = false }) {
  return (
    <div className={`pp-step ${active ? 'active' : ''} ${last ? 'last' : ''}`}>
      <div className="pp-step-num">{number}</div>
      <div className="pp-step-info">
        <div className="pp-step-label">{label}</div>
        <div className="pp-step-title">{title}</div>
      </div>
    </div>
  );
}

function EstadoTag({ estado }) {
  const normalized = (estado || '').toLowerCase();

  let className = 'pp-tag pp-tag-danger';

  if (normalized.includes('activa') || normalized.includes('vigente')) {
    className = 'pp-tag pp-tag-success';
  } else if (normalized.includes('pausada') || normalized.includes('borrador')) {
    className = 'pp-tag pp-tag-warning';
  }

  return <span className={className}>{estado || 'Sin estado'}</span>;
}