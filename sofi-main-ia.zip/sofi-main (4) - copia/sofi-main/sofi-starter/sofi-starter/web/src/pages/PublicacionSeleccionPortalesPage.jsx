import { useLocation, useNavigate } from 'react-router-dom';
import { useMemo, useState } from 'react';
import { useAuth } from '../contexts/AuthContext.jsx';

const PORTALES = [
    { id: 'occ', nombre: 'OCCMundial', tipo: 'De pago', costo: 1200 },
    { id: 'computrabajo', nombre: 'Computrabajo', tipo: 'De pago', costo: 800 },
    { id: 'sne', nombre: 'Portal del Empleo – SNE', tipo: 'Gratis', costo: 0 },
    { id: 'indeed', nombre: 'Indeed', tipo: 'Freemium', costo: 0 },
    { id: 'linkedin', nombre: 'LinkedIn Jobs', tipo: 'De pago', costo: 2100 },
    { id: 'talenteca', nombre: 'Talenteca', tipo: 'De pago', costo: 500 }
];

export default function PublicacionSeleccionPortalesPage() {
    const navigate = useNavigate();
    const location = useLocation();
    const { logout, user } = useAuth();

    const [selected, setSelected] = useState(['sne', 'indeed']);

    const vacante = location.state?.vacante || {};
    const codigo = location.state?.codigo || '#000';

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const togglePortal = (portalId) => {
        setSelected((prev) =>
            prev.includes(portalId)
                ? prev.filter((id) => id !== portalId)
                : [...prev, portalId]
        );
    };

    const selectedPortales = useMemo(
        () => PORTALES.filter((p) => selected.includes(p.id)),
        [selected]
    );

    const total = useMemo(
        () => selectedPortales.reduce((acc, p) => acc + p.costo, 0),
        [selectedPortales]
    );

    const gratisCount = selectedPortales.filter((p) => p.costo === 0).length;
    const pagoCount = selectedPortales.filter((p) => p.costo > 0).length;

    const handleContinuar = () => {
        navigate('/publicacion-portales/confirmar', {
            state: {
                vacante,
                codigo,
                portales: selectedPortales,
                total
            }
        });
    };

    return (
        <div className="pp-page-shell">
            <header className="pp-topbar">
                <div className="pp-topbar-logo">SOFI · Sistema de Reclutamiento</div>

                <div className="pp-topbar-user">
                    <span>
                        {user?.nombre ? user.nombre.toUpperCase() : 'USUARIO'} ·{' '}
                        {user?.rol ? user.rol.toUpperCase() : 'ADMIN'}
                    </span>
                    <button className="pp-btn pp-btn-teal pp-btn-sm pp-btn-auto" onClick={handleLogout}>
                        SALIR
                    </button>
                </div>
            </header>

            <div className="pp-breadcrumb">
                <a href="/">Menú administrador</a>
                <span>›</span>
                <a href="/publicacion-portales">Publicación en portales</a>
                <span>›</span>
                <strong>Seleccionar portales</strong>
            </div>

            <main className="pp-page">
                <h1 className="pp-title">Seleccionar portales de publicación</h1>
                <p className="pp-subtitle">
                    Elige en qué portales quieres publicar la vacante.
                </p>

                <div className="pp-stepper">
                    <StepItem number="✓" label="Paso 1" title="Seleccionar vacante" done />
                    <StepItem number="✓" label="Paso 2" title="Perfil & descripción" done />
                    <StepItem number="3" label="Paso 3" title="Seleccionar portales" active />
                    <StepItem number="4" label="Paso 4" title="Confirmar & publicar" last />
                </div>

                <div className="pp-grid">
                    <section className="pp-card">
                        <div className="pp-card-header pp-card-header-row">
                            <div className="pp-card-title">
                                🌐 Portales disponibles
                            </div>
                            <div className="pp-badge-count">{selected.length} seleccionados</div>
                        </div>

                        <div className="pp-card-body">
                            <div className="pp-ai-banner">
                                <div className="pp-ai-icon">✦</div>
                                <div>
                                    <div className="pp-ai-title">Sofi IA · Recomendación</div>
                                    <div className="pp-ai-text">
                                        Para este perfil conviene empezar por portales gratuitos y luego sumar portales de pago para ampliar alcance.
                                    </div>
                                </div>
                            </div>

                            <div className="pp-table-wrap">
                                <table className="pp-table">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Portal</th>
                                            <th>Tipo</th>
                                            <th>Costo</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {PORTALES.map((portal) => {
                                            const isSelected = selected.includes(portal.id);

                                            return (
                                                <tr
                                                    key={portal.id}
                                                    className={isSelected ? 'selected' : ''}
                                                    onClick={() => togglePortal(portal.id)}
                                                >
                                                    <td>
                                                        <input
                                                            type="checkbox"
                                                            checked={isSelected}
                                                            onChange={() => togglePortal(portal.id)}
                                                        />
                                                    </td>
                                                    <td>
                                                        <div className="pp-cell-title">{portal.nombre}</div>
                                                    </td>
                                                    <td>
                                                        <span
                                                            className={
                                                                portal.costo === 0
                                                                    ? 'pp-tag pp-tag-success'
                                                                    : portal.tipo === 'Freemium'
                                                                        ? 'pp-tag pp-tag-warning'
                                                                        : 'pp-tag pp-tag-danger'
                                                            }
                                                        >
                                                            {portal.tipo}
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span className="pp-code">
                                                            {portal.costo === 0
                                                                ? 'Gratis'
                                                                : `$${portal.costo.toLocaleString('es-CL')}`}
                                                        </span>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>

                            <div className="pp-actions">
                                <button
                                    className="pp-btn pp-btn-ghost pp-btn-auto"
                                    onClick={() => navigate(-1)}
                                >
                                    ← Regresar
                                </button>

                                <button className="pp-btn pp-btn-primary pp-btn-auto" onClick={handleContinuar}>
                                    Continuar → Confirmar publicación
                                </button>
                            </div>
                        </div>
                    </section>

                    <aside className="pp-side-stack">
                        <div className="pp-card pp-sidebar">
                            <div className="pp-card-header">
                                <div className="pp-card-title">💰 Resumen</div>
                            </div>

                            <div className="pp-card-body">
                                <div className="pp-sidebar-code">{codigo}</div>
                                <div className="pp-sidebar-name">
                                    {vacante.titulo || 'Vacante sin título'}
                                </div>
                                <div className="pp-sidebar-meta">
                                    {vacante.categoria || 'Sin categoría'} · {vacante.ubicacion || 'Sin ubicación'}
                                </div>

                                <hr className="pp-divider" />

                                <div className="pp-field">
                                    <div className="pp-field-label">Portales gratuitos</div>
                                    <div className="pp-field-value">{gratisCount}</div>
                                </div>

                                <div className="pp-field">
                                    <div className="pp-field-label">Portales de pago</div>
                                    <div className="pp-field-value">{pagoCount}</div>
                                </div>

                                <div className="pp-field">
                                    <div className="pp-field-label">Total estimado</div>
                                    <div className="pp-total-amount">${total.toLocaleString('es-CL')}</div>
                                </div>
                            </div>
                        </div>

                        <div className="pp-card">
                            <div className="pp-card-header">
                                <div className="pp-card-title">📌 Seleccionados</div>
                            </div>

                            <div className="pp-card-body">
                                {selectedPortales.length === 0 ? (
                                    <p className="pp-empty">No hay portales seleccionados.</p>
                                ) : (
                                    <div className="pp-chip-list">
                                        {selectedPortales.map((portal) => (
                                            <span key={portal.id} className="pp-chip">
                                                {portal.nombre}
                                            </span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </aside>
                </div>
            </main>
        </div>
    );
}

function StepItem({ number, label, title, active = false, done = false, last = false }) {
    return (
        <div className={`pp-step ${active ? 'active' : ''} ${done ? 'done' : ''} ${last ? 'last' : ''}`}>
            <div className="pp-step-num">{number}</div>
            <div className="pp-step-info">
                <div className="pp-step-label">{label}</div>
                <div className="pp-step-title">{title}</div>
            </div>
        </div>
    );
}