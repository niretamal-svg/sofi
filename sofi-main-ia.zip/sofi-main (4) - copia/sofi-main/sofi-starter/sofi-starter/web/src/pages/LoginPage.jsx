import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useGoogleLogin } from '@react-oauth/google';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, register, oauthLogin } = useAuth();

  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form states
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    if (code) {
      handleGitHubCallback(code);
    }
  }, []);

  const handleGitHubCallback = async (code) => {
    try {
      setLoading(true);
      setError('');
      // Limpiar URL para que no quede el ?code= expuesto
      window.history.replaceState({}, document.title, window.location.pathname);
      await oauthLogin('github', code);
      navigate('/');
    } catch (err) {
      setError('Error al conectar con GitHub en el servidor');
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        await login(email, password);
      } else {
        if (!nombre.trim()) throw new Error("El nombre es requerido para registrarse.");
        if (password.length < 8) throw new Error("La contraseña debe tener al menos 8 caracteres.");
        if (!/[A-Z]/.test(password)) throw new Error("La contraseña debe tener al menos una letra mayúscula.");
        if (!/[a-z]/.test(password)) throw new Error("La contraseña debe tener al menos una letra minúscula.");
        if (!/[0-9]/.test(password)) throw new Error("La contraseña debe tener al menos un número.");
        if (!/[^A-Za-z0-9]/.test(password)) throw new Error("La contraseña debe tener al menos un símbolo especial (ej. @, $, !, %, *, ?, &).");
        await register(nombre, email, password);
      }
      navigate('/');
    } catch (err) {
      if (err.response?.status === 409) {
        setError('Este correo electrónico ya está registrado. Por favor, intenta iniciar sesión.');
      } else if (err.response?.data?.details) {
        // Mostrar el primer error de validación del backend si lo hay
        setError(err.response.data.details[0].message);
      } else if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else if (err.message) {
        setError(err.message);
      } else {
        setError('Ocurrió un error. Verifica tus credenciales e intenta nuevamente.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      try {
        setLoading(true);
        setError('');
        // oauthLogin(provider, providerId, email, nombre) ... pero ahora pasamos el token en lugar del resto
        await oauthLogin('google', tokenResponse.access_token);
        navigate('/');
      } catch (err) {
        setError('Error al iniciar sesión con Google en el servidor');
      } finally {
        setLoading(false);
      }
    },
    onError: () => setError('Error al autenticar con Google')
  });

  const handleOAuth = async (provider) => {
    if (provider === 'google') {
      return handleGoogleLogin();
    }
    
    if (provider === 'github') {
      setLoading(true);
      const clientId = import.meta.env.VITE_GITHUB_CLIENT_ID;
      // Redirigir a la página oficial de GitHub
      window.location.href = `https://github.com/login/oauth/authorize?client_id=${clientId}&scope=user:email`;
    }
  };

  const toggleMode = () => {
    setIsLogin(!isLogin);
    setError('');
  };

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <div className="auth-header">
          <h1 className="auth-title">SOFI Starter</h1>
          <p className="auth-subtitle">
            {isLogin ? 'Bienvenido de nuevo' : 'Crea tu cuenta profesional'}
          </p>
        </div>

        {error && (
          <div className="error" style={{ marginBottom: '20px' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {!isLogin && (
            <div className="auth-form-group">
              <label className="auth-label">Nombre completo</label>
              <input
                className="auth-input"
                type="text"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej. Juan Pérez"
              />
            </div>
          )}

          <div className="auth-form-group">
            <label className="auth-label">Correo electrónico</label>
            <input
              className="auth-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="correo@empresa.com"
            />
          </div>

          <div className="auth-form-group">
            <label className="auth-label">Contraseña</label>
            <input
              className="auth-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <button type="submit" disabled={loading} className="auth-btn">
            {loading ? 'Procesando...' : isLogin ? 'Ingresar' : 'Registrarse'}
          </button>
        </form>

        <div className="auth-divider">o continúa con</div>

        <div className="auth-social-btns">
          <button 
            type="button" 
            className="auth-social-btn" 
            onClick={() => handleOAuth('google')}
            disabled={loading}
          >
            <svg className="auth-social-icon" viewBox="0 0 24 24" width="20" height="20" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Iniciar sesión con Google
          </button>
          
          <button 
            type="button" 
            className="auth-social-btn" 
            onClick={() => handleOAuth('github')}
            disabled={loading}
          >
            <svg className="auth-social-icon" viewBox="0 0 24 24" width="20" height="20" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
            </svg>
            Iniciar sesión con GitHub
          </button>
        </div>

        <div className="auth-toggle">
          {isLogin ? '¿No tienes una cuenta?' : '¿Ya tienes una cuenta?'}{' '}
          <button type="button" onClick={toggleMode} className="auth-toggle-link">
            {isLogin ? 'Regístrate aquí' : 'Inicia sesión'}
          </button>
        </div>
      </div>
    </div>
  );
}
