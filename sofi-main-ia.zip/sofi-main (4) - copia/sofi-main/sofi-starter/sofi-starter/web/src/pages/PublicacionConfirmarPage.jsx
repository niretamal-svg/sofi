import { useLocation, useNavigate } from 'react-router-dom';
import { useMemo } from 'react';
import { useAuth } from '../contexts/AuthContext.jsx';

export default function PublicacionConfirmarPage() {
    const navigate = useNavigate();
    const location = useLocation();
    const { logout, user } = useAuth();

    const vacante = location.state?.vacante || {};
    const codigo = location.state?.codigo || '#000';
    const portales = location.state?.portales || [];
    const total = location.state?.total || 0;

    const publicadosGratis = useMemo(
        () => portales.filter((p) => p.costo === 0),
        [portales]
    );

    const pendientesPago = useMemo(
        () => portales.filter((p) => p.costo > 0),
        [portales]
    );

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <div className="pp-page-shell">
            <header className="pp-topbar">
                <div className="pp-topbar-logo">SOFI · Sistema de Reclutamiento</div>

                <div className="pp-topbar-user">
                    <span>
                        {user?.nombre ? user.nombre.toUpperCase() : 'USUARIO'} ·{' '}
                        {user?.rol ? user.rol.toUpperCase() : 'ADMIN'}
                    </span>
                    <button className="pp-btn pp-btn-teal pp-btn-sm pp-btn-auto" onClick={handleLogout}>
                        SALIR
                    </button>
                </div>
            </header>

            <div className="pp-breadcrumb">
                <a href="/">Menú administrador</a>
                <span>›</span>
                <a href="/publicacion-portales">Publicación en portales</a>
                <span>›</span>
                <strong>Confirmar & publicar</strong>
            </div>

            <main className="pp-page">
                <h1 className="pp-title">Confirmar y publicar</h1>
                <p className="pp-subtitle">
                    Revisa el resumen final antes de completar la publicación.
                </p>

                <div className="pp-stepper">
                    <StepItem number="✓" label="Paso 1" title="Seleccionar vacante" done />
                    <StepItem number="✓" label="Paso 2" title="Perfil & descripción" done />
                    <StepItem number="✓" label="Paso 3" title="Seleccionar portales" done />
                    <StepItem number="4" label="Paso 4" title="Confirmar & publicar" active last />
                </div>

                <div className="pp-grid">
                    <section className="pp-card">
                        <div className="pp-card-header">
                            <div className="pp-card-title">🚀 Estado de publicación</div>
                        </div>

                        <div className="pp-card-body">
                            <div className="pp-summary-grid">
                                <div className="pp-summary-box">
                                    <div className="pp-field-label">Vacante</div>
                                    <div className="pp-summary-title">
                                        {codigo} · {vacante.titulo || 'Vacante sin título'}
                                    </div>
                                    <div className="pp-summary-sub">
                                        {vacante.categoria || 'Sin categoría'} · {vacante.ubicacion || 'Sin ubicación'}
                                    </div>
                                </div>

                                <div className="pp-summary-box">
                                    <div className="pp-field-label">Portales</div>
                                    <div className="pp-summary-title">{portales.length} seleccionados</div>
                                    <div className="pp-summary-sub">
                                        {publicadosGratis.length} gratuitos · {pendientesPago.length} de pago
                                    </div>
                                </div>
                            </div>

                            <div className="pp-status-list">
                                {publicadosGratis.map((portal) => (
                                    <div key={portal.id} className="pp-status-item">
                                        <div className="pp-status-dot pp-status-success"></div>
                                        <div className="pp-status-content">
                                            <div className="pp-status-name">{portal.nombre}</div>
                                            <div className="pp-status-msg">Publicado correctamente</div>
                                        </div>
                                        <span className="pp-tag pp-tag-success">✓ Publicado</span>
                                    </div>
                                ))}

                                {pendientesPago.map((portal) => (
                                    <div key={portal.id} className="pp-status-item">
                                        <div className="pp-status-dot pp-status-pending"></div>
                                        <div className="pp-status-content">
                                            <div className="pp-status-name">{portal.nombre}</div>
                                            <div className="pp-status-msg">Pendiente de pago</div>
                                        </div>
                                        <span className="pp-tag pp-tag-warning">💳 Pago pendiente</span>
                                    </div>
                                ))}

                                {portales.length === 0 && (
                                    <p className="pp-empty">No hay portales seleccionados.</p>
                                )}
                            </div>

                            <div className="pp-actions">
                                <button
                                    className="pp-btn pp-btn-ghost pp-btn-auto"
                                    onClick={() => navigate(-1)}
                                >
                                    ← Modificar selección
                                </button>

                                <button 
                                    className="pp-btn pp-btn-primary pp-btn-auto"
                                    onClick={() => {
                                        navigate('/publicacion-portales/checkout', {
                                            state: {
                                                vacante,
                                                codigo,
                                                portales,
                                                total
                                            }
                                        });
                                    }}
                                >
                                    Finalizar publicación
                                </button>
                            </div>
                        </div>
                    </section>

                    <aside className="pp-side-stack">
                        <div className="pp-card pp-sidebar">
                            <div className="pp-card-header">
                                <div className="pp-card-title">📊 Resumen final</div>
                            </div>

                            <div className="pp-card-body">
                                <div className="pp-sidebar-code">{codigo}</div>
                                <div className="pp-sidebar-name">
                                    {vacante.titulo || 'Vacante sin título'}
                                </div>
                                <div className="pp-sidebar-meta">
                                    {vacante.categoria || 'Sin categoría'} · {vacante.ubicacion || 'Sin ubicación'}
                                </div>

                                <hr className="pp-divider" />

                                <div className="pp-field">
                                    <div className="pp-field-label">Publicados gratis</div>
                                    <div className="pp-field-value">{publicadosGratis.length}</div>
                                </div>

                                <div className="pp-field">
                                    <div className="pp-field-label">Pendientes de pago</div>
                                    <div className="pp-field-value">{pendientesPago.length}</div>
                                </div>

                                <div className="pp-field">
                                    <div className="pp-field-label">Total estimado</div>
                                    <div className="pp-total-amount">${total.toLocaleString('es-CL')}</div>
                                </div>
                            </div>
                        </div>

                        <div className="pp-card">
                            <div className="pp-card-header">
                                <div className="pp-card-title">📌 Portales elegidos</div>
                            </div>

                            <div className="pp-card-body">
                                {portales.length === 0 ? (
                                    <p className="pp-empty">Sin portales seleccionados.</p>
                                ) : (
                                    <div className="pp-chip-list">
                                        {portales.map((portal) => (
                                            <span key={portal.id} className="pp-chip">
                                                {portal.nombre}
                                            </span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </aside>
                </div>
            </main>
        </div>
    );
}

function StepItem({ number, label, title, active = false, done = false, last = false }) {
    return (
        <div className={`pp-step ${active ? 'active' : ''} ${done ? 'done' : ''} ${last ? 'last' : ''}`}>
            <div className="pp-step-num">{number}</div>
            <div className="pp-step-info">
                <div className="pp-step-label">{label}</div>
                <div className="pp-step-title">{title}</div>
            </div>
        </div>
    );
}