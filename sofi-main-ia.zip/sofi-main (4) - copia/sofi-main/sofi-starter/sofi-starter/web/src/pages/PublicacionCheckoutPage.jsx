import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useState } from 'react';

export default function PublicacionCheckoutPage() {
    const navigate = useNavigate();
    const location = useLocation();
    const { logout, user } = useAuth();

    const vacante = location.state?.vacante || {};
    const codigo = location.state?.codigo || '#000';
    const portales = location.state?.portales || [];
    const total = location.state?.total || 0;

    const [isProcessing, setIsProcessing] = useState(false);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const handleWebpay = () => {
        setIsProcessing(true);
        // Simulate a redirect or connection to Webpay
        setTimeout(() => {
            alert('Redirigiendo al portal seguro de Webpay Plus...');
            setIsProcessing(false);
        }, 1500);
    };

    // Calculate taxes (e.g. IVA 19% in Chile)
    const subtotal = Math.round(total / 1.19);
    const iva = total - subtotal;

    return (
        <div className="pp-page-shell" style={{ backgroundColor: '#f3f4f6' }}>
            <header className="pp-topbar">
                <div className="pp-topbar-logo">SOFI · Sistema de Reclutamiento</div>

                <div className="pp-topbar-user">
                    <span>
                        {user?.nombre ? user.nombre.toUpperCase() : 'USUARIO'} ·{' '}
                        {user?.rol ? user.rol.toUpperCase() : 'ADMIN'}
                    </span>
                    <button className="pp-btn pp-btn-teal pp-btn-sm pp-btn-auto" onClick={handleLogout}>
                        SALIR
                    </button>
                </div>
            </header>

            <div className="pp-breadcrumb">
                <a href="/">Menú administrador</a>
                <span>›</span>
                <a href="/publicacion-portales">Publicación en portales</a>
                <span>›</span>
                <strong>Checkout & Pago</strong>
            </div>

            <main className="pp-page" style={{ maxWidth: '800px', margin: '0 auto' }}>
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <h1 className="pp-title" style={{ fontSize: '28px', color: '#111827' }}>Finaliza tu compra</h1>
                    <p className="pp-subtitle">
                        Estás a un solo paso de publicar tu vacante en los mejores portales.
                    </p>
                </div>

                <div className="pp-card" style={{ boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)', borderRadius: '16px', overflow: 'hidden' }}>
                    {/* Invoice Header */}
                    <div style={{ background: 'linear-gradient(to right, #4f46e5, #7c3aed)', color: 'white', padding: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                            <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0 0 8px 0' }}>Resumen de Publicación</h2>
                            <p style={{ margin: 0, opacity: 0.9, fontSize: '14px' }}>Ref: {codigo}</p>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                            <div style={{ fontSize: '14px', opacity: 0.9 }}>Total a pagar</div>
                            <div style={{ fontSize: '32px', fontWeight: 'bold' }}>${total.toLocaleString('es-CL')}</div>
                        </div>
                    </div>

                    <div className="pp-card-body" style={{ padding: '2rem' }}>
                        {/* Vacancy Details */}
                        <div style={{ marginBottom: '2rem' }}>
                            <h3 style={{ fontSize: '14px', textTransform: 'uppercase', color: '#6b7280', letterSpacing: '0.05em', marginBottom: '12px' }}>Detalles de la Vacante</h3>
                            <div style={{ background: '#f9fafb', border: '1px solid #e5e7eb', borderRadius: '8px', padding: '16px', display: 'flex', gap: '16px', alignItems: 'center' }}>
                                <div style={{ background: '#e0e7ff', color: '#4f46e5', width: '48px', height: '48px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px' }}>
                                    💼
                                </div>
                                <div>
                                    <div style={{ fontSize: '16px', fontWeight: '600', color: '#111827' }}>{vacante.titulo || 'Vacante sin título'}</div>
                                    <div style={{ fontSize: '14px', color: '#6b7280' }}>{vacante.categoria || 'Sin categoría'} · {vacante.ubicacion || 'Sin ubicación'}</div>
                                </div>
                            </div>
                        </div>

                        {/* Order Lines */}
                        <div style={{ marginBottom: '2rem' }}>
                            <h3 style={{ fontSize: '14px', textTransform: 'uppercase', color: '#6b7280', letterSpacing: '0.05em', marginBottom: '12px' }}>Portales Seleccionados</h3>
                            <div style={{ borderTop: '1px solid #e5e7eb' }}>
                                {portales.length > 0 ? portales.map((portal) => (
                                    <div key={portal.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 0', borderBottom: '1px solid #e5e7eb' }}>
                                        <div>
                                            <div style={{ fontWeight: '500', color: '#374151' }}>{portal.nombre}</div>
                                            <div style={{ fontSize: '13px', color: '#6b7280' }}>Publicación Premium</div>
                                        </div>
                                        <div style={{ fontWeight: '600', color: '#111827' }}>
                                            {portal.costo === 0 ? 'Gratis' : `$${portal.costo.toLocaleString('es-CL')}`}
                                        </div>
                                    </div>
                                )) : (
                                    <div style={{ padding: '16px 0', color: '#6b7280', fontStyle: 'italic' }}>No seleccionaste ningún portal.</div>
                                )}
                            </div>
                        </div>

                        {/* Totals */}
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '2rem' }}>
                            <div style={{ width: '100%', maxWidth: '300px' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '8px', color: '#6b7280' }}>
                                    <span>Subtotal</span>
                                    <span>${subtotal.toLocaleString('es-CL')}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '16px', color: '#6b7280', borderBottom: '1px solid #e5e7eb' }}>
                                    <span>IVA (19%)</span>
                                    <span>${iva.toLocaleString('es-CL')}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: '16px', fontWeight: 'bold', fontSize: '20px', color: '#111827' }}>
                                    <span>Total</span>
                                    <span>${total.toLocaleString('es-CL')}</span>
                                </div>
                            </div>
                        </div>

                        {/* Actions */}
                        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', justifyContent: 'space-between', marginTop: '32px' }}>
                            <button
                                className="pp-btn pp-btn-ghost"
                                onClick={() => navigate(-1)}
                                style={{ padding: '12px 24px' }}
                            >
                                ← Volver
                            </button>

                            <button 
                                className="pp-btn" 
                                onClick={handleWebpay}
                                disabled={isProcessing}
                                style={{ 
                                    background: '#ed1c24', // Webpay red
                                    color: 'white', 
                                    padding: '14px 32px', 
                                    fontSize: '16px', 
                                    fontWeight: 'bold', 
                                    borderRadius: '8px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    boxShadow: '0 4px 6px -1px rgba(237, 28, 36, 0.3)',
                                    transition: 'all 0.2s',
                                    border: 'none',
                                    cursor: isProcessing ? 'wait' : 'pointer'
                                }}
                            >
                                {isProcessing ? (
                                    <>
                                        <span className="pp-spinner" style={{ borderColor: 'white', borderTopColor: 'transparent', width: '16px', height: '16px', borderWidth: '2px' }}></span>
                                        Conectando...
                                    </>
                                ) : (
                                    <>
                                        💳 Pagar con Webpay
                                    </>
                                )}
                            </button>
                        </div>
                        
                        <div style={{ textAlign: 'center', marginTop: '24px', fontSize: '13px', color: '#9ca3af', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                            🔒 Pagos procesados de forma segura mediante Transbank
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}
