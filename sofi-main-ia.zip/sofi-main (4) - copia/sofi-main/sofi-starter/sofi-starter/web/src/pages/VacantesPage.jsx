import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api.js';
import { useAuth } from '../contexts/AuthContext.jsx';

export default function VacantesPage() {
  const navigate = useNavigate();
  const { logout } = useAuth();

  const [vacantes, setVacantes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchVacantes = async () => {
    try {
      setLoading(true);
      setError('');
      const { data } = await api.get('/vacantes');
      setVacantes(data.data || []);
    } catch (err) {
      setError('No se pudieron cargar las vacantes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVacantes();
  }, []);

  const handleEdit = (vacante) => {
    navigate(`/publicacion-portales/${vacante._id}/perfil`, {
      state: {
        vacante,
        codigo: `#${vacante.numero || String(vacante._id).slice(-4).toUpperCase()}`
      }
    });
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm('¿Seguro que deseas eliminar esta vacante?');

    if (!confirmDelete) return;

    try {
      setError('');
      await api.delete(`/vacantes/${id}`);
      await fetchVacantes();
    } catch (err) {
      setError('No se pudo eliminar la vacante');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f6f7fb', padding: '24px' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '24px',
            gap: '12px',
            flexWrap: 'wrap'
          }}
        >
          <div>
            <h1 style={{ margin: 0 }}>Gestión de vacantes</h1>
            <p style={{ margin: '8px 0 0', color: '#666' }}>
              Visualiza y administra tus vacantes.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={() => navigate('/')}
              className="pp-btn pp-btn-primary"
              style={{ width: '130px', textAlign: 'center' }}
            >
              Menu
            </button>

            <button
              onClick={() => navigate('/publicacion-portales')}
              className="pp-btn pp-btn-primary"
              style={{ width: '130px', textAlign: 'center' }}
            >
              Crear vacante
            </button>

            <button
              onClick={handleLogout}
              className="pp-btn pp-btn-primary"
              style={{ width: '130px', textAlign: 'center' }}
            >
              Cerrar sesión
            </button>
          </div>
        </div>

        {error && (
          <div
            style={{
              marginBottom: '16px',
              padding: '12px 16px',
              background: '#ffe7e7',
              border: '1px solid #ffb9b9',
              borderRadius: '10px',
              color: '#9b1c1c'
            }}
          >
            {error}
          </div>
        )}

        <div
          style={{
            background: '#fff',
            borderRadius: '16px',
            padding: '24px',
            boxShadow: '0 10px 30px rgba(0,0,0,0.06)'
          }}
        >
          <h2 style={{ marginTop: 0 }}>Listado de vacantes</h2>

          {loading ? (
            <p>Cargando vacantes...</p>
          ) : vacantes.length === 0 ? (
            <p>No hay vacantes registradas todavía.</p>
          ) : (
            <div style={{ display: 'grid', gap: '14px' }}>
              {vacantes.map((vacante) => (
                <div
                  key={vacante._id}
                  style={{
                    border: '1px solid #e5e7eb',
                    borderRadius: '12px',
                    padding: '16px'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
                    <div style={{ width: '100%' }}>
                      <h3 style={{ margin: '0 0 8px' }}>{vacante.titulo}</h3>
                      <p style={{ margin: '0 0 6px', color: '#444' }}>
                        <strong>Empresa:</strong> {vacante.empresa}
                      </p>
                      <p style={{ margin: '0 0 6px', color: '#444' }}>
                        <strong>Ubicación:</strong> {vacante.ubicacion}
                      </p>
                      <p style={{ margin: '0 0 6px', color: '#444' }}>
                        <strong>Modalidad:</strong> {vacante.modalidad}
                      </p>
                      <p style={{ margin: '0 0 6px', color: '#444' }}>
                        <strong>Salario:</strong> ${Number(vacante.salario || 0).toLocaleString('es-CL')}
                      </p>
                      <p style={{ margin: '0 0 10px', color: '#444' }}>
                        <strong>Estado:</strong> {vacante.estado}
                      </p>
                      <p style={{ margin: 0, color: '#666' }}>{vacante.descripcion}</p>

                      <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
                        <button
                          onClick={() => handleEdit(vacante)}
                          style={{
                            padding: '8px 12px',
                            borderRadius: '8px',
                            border: 'none',
                            background: '#2563eb',
                            color: '#fff',
                            cursor: 'pointer'
                          }}
                        >
                          Editar
                        </button>

                        <button
                          onClick={() => handleDelete(vacante._id)}
                          style={{
                            padding: '8px 12px',
                            borderRadius: '8px',
                            border: 'none',
                            background: '#dc2626',
                            color: '#fff',
                            cursor: 'pointer'
                          }}
                        >
                          Eliminar
                        </button>
                      </div>
                    </div>

                    <span
                      style={{
                        alignSelf: 'flex-start',
                        padding: '6px 10px',
                        borderRadius: '999px',
                        background:
                          vacante.estado === 'Activa'
                            ? '#dcfce7'
                            : vacante.estado === 'Pausada'
                              ? '#fef3c7'
                              : '#fee2e2',
                        color:
                          vacante.estado === 'Activa'
                            ? '#166534'
                            : vacante.estado === 'Pausada'
                              ? '#92400e'
                              : '#991b1b',
                        fontWeight: 700,
                        fontSize: '12px'
                      }}
                    >
                      {vacante.estado}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}