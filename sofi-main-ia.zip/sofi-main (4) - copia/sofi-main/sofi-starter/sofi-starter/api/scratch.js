import { GoogleGenerativeAI } from '@google/generative-ai';
import { env } from './src/config/env.js';

const genAI = new GoogleGenerativeAI(env.GEMINI_API_KEY);

async function listModels() {
  try {
    // There is no explicit listModels method in the JS SDK? Let's use fetch directly.
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${env.GEMINI_API_KEY}`);
    const data = await response.json();
    console.log(data.models.map(m => m.name));
  } catch (e) {
    console.error(e);
  }
}
listModels();
