import { aiService } from './src/services/aiService.js';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { env } from './src/config/env.js';

async function run() {
    try {
        const genAI = new GoogleGenerativeAI(env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: "gemma-3-12b-it" });
        const result = await model.generateContent("Hola, escribe 3 palabras.");
        console.log("TEXT CHUNK:", result.response.text());
    } catch (e) {
        console.error("ERROR:", e);
    }
    process.exit(0);
}

run();
