import { aiService } from './src/services/aiService.js';
import mongoose from 'mongoose';
import { env } from './src/config/env.js';

async function run() {
    try {
        const stream = await aiService.generateProfileStream({
            titulo: 'junior',
            categoria: 'Ventas',
            jornada: 'Tiempo completo',
            salario: '1111111',
            ubicacion: 'Mexico'
        });
        
        for await (const chunk of stream) {
            console.log("TEXT CHUNK:", chunk.text());
        }
    } catch (e) {
        console.error("ERROR:", e);
    }
    process.exit(0);
}

run();
