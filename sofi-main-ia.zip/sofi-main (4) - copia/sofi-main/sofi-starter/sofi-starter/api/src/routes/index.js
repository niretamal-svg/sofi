import { Router } from 'express';
import authRoutes from './authRoutes.js';
import vacanteRoutes from './vacanteRoutes.js';
import aiRoutes from './aiRoutes.js';

const router = Router();

router.use('/auth', authRoutes);
router.use('/vacantes', vacanteRoutes);
router.use('/ai', aiRoutes);

export default router;