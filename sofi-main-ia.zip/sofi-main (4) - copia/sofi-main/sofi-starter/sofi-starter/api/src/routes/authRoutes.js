import { Router } from 'express';
import { login, register, oauthLogin, me, seedAdmin } from '../controllers/authController.js';
import { authenticateToken } from '../middlewares/authenticateToken.js';

const router = Router();

router.post('/login', login);
router.post('/register', register);
router.post('/oauth', oauthLogin);
router.post('/seed-admin', seedAdmin);
router.get('/me', authenticateToken, me);

export default router;
