import { Router } from 'express';
import { getPortales } from '../controllers/portalController.js';

const router = Router();

router.get('/', getPortales);

export default router;
