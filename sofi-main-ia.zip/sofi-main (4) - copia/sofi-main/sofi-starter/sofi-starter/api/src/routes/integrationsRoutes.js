import { Router } from 'express';
import { publishToPortals } from '../controllers/integrationsController.js';

const router = Router();

router.post('/publish', publishToPortals);

export default router;
