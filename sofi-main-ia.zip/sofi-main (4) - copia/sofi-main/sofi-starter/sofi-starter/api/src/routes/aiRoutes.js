import { Router } from 'express';
import { aiController } from '../controllers/aiController.js';

const router = Router();

router.post('/generate-profile', aiController.generateProfileStream);
router.post('/suggestions', aiController.generateSuggestions);

export default router;
