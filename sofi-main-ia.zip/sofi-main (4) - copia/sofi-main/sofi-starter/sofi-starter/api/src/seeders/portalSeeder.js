import { Portal } from '../models/Portal.js';

const INITIAL_PORTALES = [
    // MÉXICO
    { id_interno: 'occ', nombre: 'OCCMundial', url: 'occ.com.mx · Bolsa MX', tipo: 'De pago', costo: 1200, country: 'mx', modelo: 'Bolsa' },
    { id_interno: 'computrabajo-mx', nombre: 'Computrabajo México', url: 'mx.computrabajo.com', tipo: 'De pago', costo: 800, country: 'mx', modelo: 'Bolsa' },
    { id_interno: 'sne', nombre: 'Portal del Empleo – SNE', url: 'empleo.gob.mx · Gobierno', tipo: 'Gratis', costo: 0, country: 'mx', modelo: 'Gobierno' },
    { id_interno: 'indeed-mx', nombre: 'Indeed México', url: 'indeed.com.mx · Agregador', tipo: 'Gratis', costo: 0, country: 'mx', modelo: 'Freemium' },
    { id_interno: 'talenteca', nombre: 'Talenteca', url: 'talenteca.com · Bolsa', tipo: 'De pago', costo: 500, country: 'mx', modelo: 'Bolsa' },
    { id_interno: 'linkedin-mx', nombre: 'LinkedIn Jobs MX', url: 'linkedin.com · Red profesional', tipo: 'De pago', costo: 2100, country: 'mx', modelo: 'Red social' },

    // GUATEMALA
    { id_interno: 'empleo-gt', nombre: 'Tu Empleo Guatemala', url: 'tuempleo.mintrabajo.gob.gt', tipo: 'Gratis', costo: 0, country: 'gt', modelo: 'Gobierno' },
    { id_interno: 'computrabajo-gt', nombre: 'Computrabajo Guatemala', url: 'gt.computrabajo.com', tipo: 'De pago', costo: 350, country: 'gt', modelo: 'Bolsa' },
    { id_interno: 'tecoloco-gt', nombre: 'Tecoloco Guatemala', url: 'tecoloco.com.gt', tipo: 'De pago', costo: 420, country: 'gt', modelo: 'Bolsa' },

    // CHILE
    { id_interno: 'laborum-cl', nombre: 'Laborum', url: 'laborum.cl', tipo: 'De pago', costo: 1000, country: 'cl', modelo: 'Bolsa' },
    { id_interno: 'computrabajo-cl', nombre: 'Computrabajo Chile', url: 'cl.computrabajo.com', tipo: 'De pago', costo: 750, country: 'cl', modelo: 'Bolsa' },
    { id_interno: 'bne-cl', nombre: 'Bolsa Nacional de Empleo', url: 'bne.cl', tipo: 'Gratis', costo: 0, country: 'cl', modelo: 'Gobierno' },
    { id_interno: 'indeed-cl', nombre: 'Indeed Chile', url: 'cl.indeed.com', tipo: 'Gratis', costo: 0, country: 'cl', modelo: 'Freemium' },

    // COLOMBIA
    { id_interno: 'elempleo-co', nombre: 'El Empleo Colombia', url: 'elempleo.com/co', tipo: 'De pago', costo: 1100, country: 'co', modelo: 'Bolsa' },
    { id_interno: 'computrabajo-co', nombre: 'Computrabajo Colombia', url: 'co.computrabajo.com', tipo: 'De pago', costo: 600, country: 'co', modelo: 'Bolsa' },
    { id_interno: 'spe-co', nombre: 'Servicio Público de Empleo', url: 'serviciodeempleo.gov.co', tipo: 'Gratis', costo: 0, country: 'co', modelo: 'Gobierno' },
    { id_interno: 'indeed-co', nombre: 'Indeed Colombia', url: 'co.indeed.com', tipo: 'Gratis', costo: 0, country: 'co', modelo: 'Freemium' },

    // GLOBAL
    { id_interno: 'tecoloco-reg', nombre: 'Tecoloco Regional', url: 'tecoloco.com · CA', tipo: 'De pago', costo: 900, country: 'global', modelo: 'Bolsa' },
    { id_interno: 'google-jobs', nombre: 'Google for Jobs', url: 'SEO estructurado', tipo: 'Gratis', costo: 0, country: 'global', modelo: 'SEO' },
];

export const seedPortales = async () => {
    try {
        const count = await Portal.countDocuments();
        if (count === 0) {
            console.log('Seeding initial portales...');
            await Portal.insertMany(INITIAL_PORTALES);
            console.log('Portales seeded successfully.');
        } else {
            // Update any missing portals if necessary (simplified for now)
            for (const portal of INITIAL_PORTALES) {
                await Portal.updateOne({ id_interno: portal.id_interno }, { $set: portal }, { upsert: true });
            }
        }
    } catch (error) {
        console.error('Error seeding portales:', error);
    }
};
