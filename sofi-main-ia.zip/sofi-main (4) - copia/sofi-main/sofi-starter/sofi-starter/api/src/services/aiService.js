import { GoogleGenerativeAI } from '@google/generative-ai';
import { env } from '../config/env.js';

let genAI = null;
let model = null;

const initModel = () => {
    if (!genAI && env.GEMINI_API_KEY) {
        genAI = new GoogleGenerativeAI(env.GEMINI_API_KEY);
        model = genAI.getGenerativeModel({ model: "gemma-3-12b-it" });
    }
}

export const aiService = {
    generateProfileStream: async (data) => {
        initModel();
        if (!model) {
            throw new Error("GEMINI_API_KEY no está configurada");
        }

        const prompt = `
        Actúa como un reclutador. Sé EXTREMADAMENTE BREVE Y DIRECTO.
        Tengo una vacante:
        Título: ${data.titulo}
        Categoría: ${data.categoria}
        Jornada: ${data.jornada}
        Salario: ${data.salario}
        Ubicación: ${data.ubicacion}

        Necesito que redactes dos cosas muy cortas:
        1. Una "Descripción del puesto" de MÁXIMO 3 a 4 LÍNEAS. Sé súper conciso.
        2. Una lista de "Requisitos" con MÁXIMO 4 VIÑETAS CORTAS. Nada de explicaciones largas.

        Devuelve exactamente el siguiente formato usando estas etiquetas estrictas:

        [DESCRIPCION]
        <Escribe la descripción aquí>

        [REQUISITOS]
        <Escribe los requisitos aquí con viñetas>
        `;

        const result = await model.generateContent(prompt);
        return [{ text: () => result.response.text() }];
    },

    generateSuggestions: async (data) => {
        initModel();
        if (!model) {
            throw new Error("GEMINI_API_KEY no está configurada");
        }

        const prompt = `
        Actúa como un experto en atracción de talento.
        Tengo el siguiente borrador de una vacante:
        Título: ${data.titulo}
        Categoría: ${data.categoria}
        Jornada: ${data.jornada}
        Salario: ${data.salario}
        Ubicación: ${data.ubicacion}
        Descripción: ${data.descripcion}
        Requisitos: ${data.requisitos}

        Dame 3 sugerencias breves y directas sobre cómo puedo mejorar esta oferta de trabajo para que sea más atractiva para los candidatos.
        
        Devuelve únicamente un arreglo JSON de strings, sin formato markdown adicional (\`\`\`json ... \`\`\`):
        ["Sugerencia 1", "Sugerencia 2", "Sugerencia 3"]
        `;

        const result = await model.generateContent(prompt);
        const text = result.response.text();
        
        try {
            const cleanedText = text.replace(/```json/g, '').replace(/```/g, '').trim();
            return JSON.parse(cleanedText);
        } catch (e) {
            console.error("Error parseando respuesta de Gemini", e, text);
            return ["Asegúrate de detallar los beneficios adicionales.", "Usa un lenguaje inclusivo y cercano.", "Destaca las oportunidades de crecimiento."];
        }
    }
};
