import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { OAuth2Client } from 'google-auth-library';
import { User } from '../models/User.js';
import { env } from '../config/env.js';

const googleClient = new OAuth2Client(env.GOOGLE_CLIENT_ID);

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

const registerSchema = z.object({
  nombre: z.string().min(2),
  email: z.string().email(),
  password: z.string()
    .min(8, 'Debe tener al menos 8 caracteres')
    .regex(/[A-Z]/, 'Debe contener al menos una mayúscula')
    .regex(/[a-z]/, 'Debe contener al menos una minúscula')
    .regex(/[0-9]/, 'Debe contener al menos un número')
    .regex(/[^A-Za-z0-9]/, 'Debe contener al menos un símbolo especial')
});

const oauthSchema = z.object({
  provider: z.enum(['google', 'github']),
  token: z.string() // El frontend ahora nos envía el token de OAuth, no los datos sueltos
});

export const loginUser = async (payload) => {
  const parsed = loginSchema.safeParse(payload);

  if (!parsed.success) {
    const err = new Error('Validation error');
    err.status = 400;
    err.code = 'ERR_VALIDATION';
    err.details = parsed.error.issues.map((issue) => ({
      field: issue.path.join('.'),
      message: issue.message
    }));
    throw err;
  }

  const { email, password } = parsed.data;
  const user = await User.findOne({ email: email.toLowerCase(), activo: true });

  if (!user || !user.password_hash) {
    const err = new Error('Invalid credentials');
    err.status = 401;
    err.code = 'ERR_INVALID_CREDENTIALS';
    throw err;
  }

  const isValid = await bcrypt.compare(password, user.password_hash);

  if (!isValid) {
    const err = new Error('Invalid credentials');
    err.status = 401;
    err.code = 'ERR_INVALID_CREDENTIALS';
    throw err;
  }

  user.ultimo_acceso = new Date();
  await user.save();

  const token = jwt.sign(
    {
      sub: user._id.toString(),
      email: user.email,
      rol: user.rol,
      empresa_id: user.empresa_id
    },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );

  return {
    access_token: token,
    user: {
      id: user._id,
      nombre: user.nombre,
      email: user.email,
      rol: user.rol
    }
  };
};

export const registerUser = async (payload) => {
  const parsed = registerSchema.safeParse(payload);

  if (!parsed.success) {
    const err = new Error('Validation error');
    err.status = 400;
    err.code = 'ERR_VALIDATION';
    err.details = parsed.error.issues.map((issue) => ({
      field: issue.path.join('.'),
      message: issue.message
    }));
    throw err;
  }

  const { nombre, email, password } = parsed.data;

  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) {
    const err = new Error('Email is already registered');
    err.status = 409;
    err.code = 'ERR_DUPLICATE_EMAIL';
    throw err;
  }

  const password_hash = await bcrypt.hash(password, env.BCRYPT_ROUNDS);
  
  const user = await User.create({
    nombre,
    email: email.toLowerCase(),
    password_hash,
    rol: 'reclutador', // Default rol para nuevos registros
    activo: true,
    ultimo_acceso: new Date()
  });

  const token = jwt.sign(
    {
      sub: user._id.toString(),
      email: user.email,
      rol: user.rol,
      empresa_id: user.empresa_id
    },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );

  return {
    access_token: token,
    user: {
      id: user._id,
      nombre: user.nombre,
      email: user.email,
      rol: user.rol
    }
  };
};

export const oauthLoginUser = async (payload) => {
  const parsed = oauthSchema.safeParse(payload);

  if (!parsed.success) {
    const err = new Error('Validation error');
    err.status = 400;
    err.code = 'ERR_VALIDATION';
    err.details = parsed.error.issues.map((issue) => ({
      field: issue.path.join('.'),
      message: issue.message
    }));
    throw err;
  }

  const { provider, token } = parsed.data;
  
  let providerId, email, nombre;

  if (provider === 'google') {
    try {
      // Obtenemos los datos del usuario usando el access_token
      const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch user info');
      const payload = await response.json();
      
      providerId = payload.sub;
      email = payload.email;
      nombre = payload.name;
    } catch (e) {
      const err = new Error('Google token invalid');
      err.status = 401;
      err.code = 'ERR_OAUTH_INVALID';
      throw err;
    }
  } else if (provider === 'github') {
    try {
      // 1. Intercambiar code por access_token
      const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        body: JSON.stringify({
          client_id: env.GITHUB_CLIENT_ID,
          client_secret: env.GITHUB_CLIENT_SECRET,
          code: token
        })
      });
      const tokenData = await tokenResponse.json();
      if (tokenData.error) throw new Error(tokenData.error_description || tokenData.error);
      
      const accessToken = tokenData.access_token;
      
      // 2. Obtener perfil del usuario
      const userResponse = await fetch('https://api.github.com/user', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!userResponse.ok) throw new Error('Failed to fetch github user info');
      const userPayload = await userResponse.json();
      
      providerId = userPayload.id.toString();
      nombre = userPayload.name || userPayload.login;
      
      // 3. Obtener email (GitHub puede tenerlo privado, así que usamos el endpoint de emails)
      const emailsResponse = await fetch('https://api.github.com/user/emails', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!emailsResponse.ok) throw new Error('Failed to fetch github emails');
      const emailsPayload = await emailsResponse.json();
      
      const primaryEmail = emailsPayload.find(e => e.primary) || emailsPayload[0];
      email = primaryEmail.email;
    } catch (e) {
      const err = new Error('GitHub oauth failed: ' + e.message);
      err.status = 401;
      err.code = 'ERR_OAUTH_INVALID';
      throw err;
    }
  } else {
    const err = new Error('Provider not implemented yet');
    err.status = 501;
    throw err;
  }

  // Buscar si el usuario ya existe por email
  let user = await User.findOne({ email: email.toLowerCase() });

  if (user) {
    // Si existe, actualizar con su providerId si no lo tenía
    if (provider === 'google' && !user.googleId) user.googleId = providerId;
    if (provider === 'github' && !user.githubId) user.githubId = providerId;
    user.ultimo_acceso = new Date();
    await user.save();
  } else {
    // Si no existe, crear el usuario sin password
    user = await User.create({
      nombre,
      email: email.toLowerCase(),
      googleId: provider === 'google' ? providerId : null,
      githubId: provider === 'github' ? providerId : null,
      rol: 'reclutador',
      activo: true,
      ultimo_acceso: new Date()
    });
  }

  const jwtToken = jwt.sign(
    {
      sub: user._id.toString(),
      email: user.email,
      rol: user.rol,
      empresa_id: user.empresa_id
    },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );

  return {
    access_token: jwtToken,
    user: {
      id: user._id,
      nombre: user.nombre,
      email: user.email,
      rol: user.rol
    }
  };
};

export const seedAdminUser = async () => {
  const existing = await User.findOne({ email: 'admin@sofi.local' });
  if (existing) return existing;

  const password_hash = await bcrypt.hash('Admin12345*', env.BCRYPT_ROUNDS);
  const user = await User.create({
    nombre: 'Administrador SOFI',
    email: 'admin@sofi.local',
    password_hash,
    rol: 'admin',
    activo: true
  });

  return user;
};
