import nodemailer from 'nodemailer';
import { env } from '../config/env.js';

// Configurar el transportador usando variables de entorno o imprimir a consola en desarrollo
const transporter = nodemailer.createTransport({
  host: env.SMTP_HOST,
  port: env.SMTP_PORT,
  auth: {
    user: env.SMTP_USER,
    pass: env.SMTP_PASS,
  },
});

export const sendEmail = async (to, subject, text, html) => {
  // En desarrollo (si no hay credenciales SMTP reales), solo imprimimos en consola
  if (!env.SMTP_USER || !env.SMTP_PASS) {
    console.log('\n=============================================');
    console.log(`[EMAIL SIMULADO] Para: ${to}`);
    console.log(`[EMAIL SIMULADO] Asunto: ${subject}`);
    console.log(`[EMAIL SIMULADO] Contenido: \n${text}`);
    console.log('=============================================\n');
    return true;
  }

  try {
    const info = await transporter.sendMail({
      from: env.SMTP_FROM,
      to,
      subject,
      text,
      html,
    });
    console.log('Correo enviado: %s', info.messageId);
    return true;
  } catch (error) {
    console.error('Error al enviar correo:', error);
    throw new Error('Error al enviar el correo electrónico');
  }
};
