import mongoose from 'mongoose';

const portalSchema = new mongoose.Schema({
  id_interno: {
    type: String,
    required: true,
    unique: true
  },
  nombre: {
    type: String,
    required: true
  },
  url: {
    type: String,
    required: true
  },
  tipo: {
    type: String, // Gratis, De pago, Freemium
    required: true
  },
  costo: {
    type: Number,
    required: true,
    default: 0
  },
  country: {
    type: String, // 'mx', 'gt', 'cl', 'co', 'global', etc.
    required: true
  },
  modelo: {
    type: String, // Bolsa, Gobierno, Agregador, Red social, SEO
    required: true
  },
  activo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

export const Portal = mongoose.model('Portal', portalSchema);
