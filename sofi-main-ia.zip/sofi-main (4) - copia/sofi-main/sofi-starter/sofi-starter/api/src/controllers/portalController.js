import { Portal } from '../models/Portal.js';

export const getPortales = async (req, res) => {
  try {
    const portales = await Portal.find({ activo: true }).sort({ country: 1, costo: 1 });
    res.json({ portales });
  } catch (error) {
    console.error('Error fetching portales:', error);
    res.status(500).json({ message: 'Error interno del servidor al obtener portales' });
  }
};
