import { aiService } from '../services/aiService.js';
import { logger } from '../utils/logger.js';
export const aiController = {
    generateProfileStream: async (req, res, next) => {
        try {
            const data = req.body;
            const stream = await aiService.generateProfileStream(data);

            res.writeHead(200, {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive'
            });

            for await (const chunk of stream) {
                const text = chunk.text();
                // We send JSON payload for easy parsing on frontend
                res.write(`data: ${JSON.stringify({ text })}\n\n`);
            }
            
            res.write(`data: [DONE]\n\n`);
            res.end();
        } catch (error) {
            logger.error('Error generating profile stream via AI', error);
            // It's possible headers are already sent, handle gracefully
            if (!res.headersSent) {
                res.status(500).json({ message: error.message || 'Error generating profile stream' });
            } else {
                res.end();
            }
        }
    },

    generateSuggestions: async (req, res, next) => {
        try {
            const data = req.body;
            const result = await aiService.generateSuggestions(data);
            res.status(200).json(result);
        } catch (error) {
            logger.error('Error generating suggestions via AI', error);
            res.status(500).json({ message: error.message || 'Error generating suggestions' });
        }
    }
};
