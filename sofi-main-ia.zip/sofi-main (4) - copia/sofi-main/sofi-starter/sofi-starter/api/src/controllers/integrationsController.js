export const publishToPortals = async (req, res) => {
  try {
    const { vacante, portales } = req.body;

    if (!vacante || !portales || portales.length === 0) {
      return res.status(400).json({ message: 'Se requiere información de la vacante y los portales.' });
    }

    const results = [];

    for (const portal of portales) {
      // Simular tiempo de conexión a la API externa
      const networkDelay = Math.floor(Math.random() * 1500) + 1000; 
      await new Promise(resolve => setTimeout(resolve, networkDelay));

      // Construcción del Payload simulado
      const externalPayload = {
        job_title: vacante.titulo,
        company: 'Empresa Demo', // O extraer de la sesión
        location: vacante.ubicacion,
        description: vacante.descripcion,
        requirements: vacante.requisitos,
        salary: vacante.salario,
        job_type: vacante.jornada,
        publisher: 'SOFI Integration Service'
      };

      console.log(`[INTEGRATION] Enviando payload a API de ${portal.nombre}...`);
      console.log(JSON.stringify(externalPayload, null, 2));

      // Simular respuesta exitosa
      results.push({
        portal_id: portal.id_interno,
        portal_nombre: portal.nombre,
        status: 'success',
        external_job_id: `EXT-${Math.floor(Math.random() * 900000) + 100000}`,
        url: `https://${portal.url.split(' ')[0]}/job/${Math.floor(Math.random() * 10000)}`
      });
    }

    res.json({
      message: 'Publicación exitosa en los portales seleccionados.',
      results
    });

  } catch (error) {
    console.error('Error in integrations:', error);
    res.status(500).json({ message: 'Ocurrió un error al intentar publicar en los portales externos.' });
  }
};
