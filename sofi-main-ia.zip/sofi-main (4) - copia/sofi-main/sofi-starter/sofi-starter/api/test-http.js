import http from 'http';

const req = http.request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/v1/ai/generate-profile',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    }
}, (res) => {
    console.log(`STATUS: ${res.statusCode}`);
    res.on('data', (chunk) => {
        console.log(`BODY: ${chunk.toString()}`);
    });
    res.on('end', () => {
        console.log('No more data in response.');
    });
});

req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
});

req.write(JSON.stringify({ titulo: 'junior programador' }));
req.end();
